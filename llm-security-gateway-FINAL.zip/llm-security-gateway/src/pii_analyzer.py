import re
from typing import List, Dict

from presidio_analyzer import AnalyzerEngine, Pattern, PatternRecognizer
from presidio_analyzer.nlp_engine import NlpEngineProvider


class CustomPresidioAnalyzer:
    """
    Custom Presidio analyzer with security-focused improvements.

    Customizations:
    1. Pakistani phone number recognizer  (PK_PHONE_NUMBER)
    2. API key recognizer                 (API_KEY)
    3. Student / Employee ID recognizer   (STUDENT_ID)
    4. Password pattern recognizer        (PASSWORD)
    5. Context-aware confidence boosting
    6. Composite credential detection
    """

    def __init__(self):
        print("🔧 Initializing Custom Presidio Analyzer...")

        configuration = {
            "nlp_engine_name": "spacy",
            "models": [{"lang_code": "en", "model_name": "en_core_web_lg"}],
        }

        provider = NlpEngineProvider(nlp_configuration=configuration)
        nlp_engine = provider.create_engine()

        self.analyzer = AnalyzerEngine(nlp_engine=nlp_engine)

        # Register all custom recognizers
        self._add_pakistani_phone_recognizer()
        self._add_api_key_recognizer()
        self._add_student_id_recognizer()
        self._add_password_recognizer()

        print("✅ Custom Presidio Analyzer ready!")
        print("   📱 Pakistani phone recognizer    — PK_PHONE_NUMBER")
        print("   🔑 API key recognizer             — API_KEY")
        print("   🎓 Student/Employee ID recognizer — STUDENT_ID")
        print("   🔐 Password recognizer            — PASSWORD")

    # ── Custom Recognizer 1: Pakistani Phone ─────────────────────────────────
    def _add_pakistani_phone_recognizer(self):
        patterns = [
            Pattern("pk_phone_intl",     r"\+92[- ]?\d{3}[- ]?\d{7}",  0.90),
            Pattern("pk_phone_domestic", r"03\d{2}[- ]?\d{7}",          0.85),
        ]
        recognizer = PatternRecognizer(
            supported_entity="PK_PHONE_NUMBER",
            patterns=patterns,
            context=["phone", "call", "contact", "mobile", "whatsapp", "number"],
        )
        self.analyzer.registry.add_recognizer(recognizer)

    # ── Custom Recognizer 2: API Key ─────────────────────────────────────────
    def _add_api_key_recognizer(self):
        patterns = [
            Pattern("openai_key",     r"sk-[A-Za-z0-9]{32,}",                  0.95),
            Pattern("generic_api_key",r"(api|key|token|secret)[-_]?[A-Za-z0-9]{20,}", 0.75),
        ]
        recognizer = PatternRecognizer(
            supported_entity="API_KEY",
            patterns=patterns,
            context=["api", "token", "key", "secret", "auth", "bearer"],
        )
        self.analyzer.registry.add_recognizer(recognizer)

    # ── Custom Recognizer 3: Student / Employee ID ────────────────────────────
    def _add_student_id_recognizer(self):
        patterns = [
            Pattern("bahria_student_id", r"\d{2}-[A-Z]{2,6}-\d{3,4}",       0.90),
            Pattern("employee_id",       r"\b(EMP|HR|USR)-\d{4,8}\b",        0.88),
        ]
        recognizer = PatternRecognizer(
            supported_entity="STUDENT_ID",
            patterns=patterns,
            context=["student", "id", "roll", "registration", "enrollment", "employee"],
        )
        self.analyzer.registry.add_recognizer(recognizer)

    # ── Custom Recognizer 4: Password ────────────────────────────────────────
    def _add_password_recognizer(self):
        patterns = [
            Pattern("password_colon",    r"(password|pass|pwd)\s*[:=]\s*\S+", 0.90),
            Pattern("password_sentence", r"password\s+is\s+\S+",              0.85),
        ]
        recognizer = PatternRecognizer(
            supported_entity="PASSWORD",
            patterns=patterns,
            context=["password", "pass", "pwd", "secret", "credential"],
        )
        self.analyzer.registry.add_recognizer(recognizer)

    # ── Context-Aware Analysis (Customization 5) ─────────────────────────────
    def analyze_text(self, text: str, language: str = "en") -> List[Dict]:
        """
        Analyze text for PII with context-aware confidence boosting.
        Sensitive context words (password, secret, etc.) boost score by 30%.
        """
        results = self.analyzer.analyze(text=text, language=language)

        text_lower = text.lower()
        sensitive_keywords = ["password", "secret", "confidential", "private", "sensitive"]

        enhanced = []
        for result in results:
            score = result.score
            # Boost confidence when sensitive context present
            if any(w in text_lower for w in sensitive_keywords):
                score = min(score * 1.30, 1.0)

            enhanced.append({
                "entity_type": result.entity_type,
                "start":       result.start,
                "end":         result.end,
                "score":       round(score, 3),
                "text":        text[result.start:result.end],
            })

        return enhanced

    # ── Composite Credential Detection (Customization 6) ─────────────────────
    def detect_composite_entities(self, text: str) -> List[Dict]:
        """
        Detect username+password pairs, email+password pairs, etc.
        These are critical credential leaks even if each piece alone is low risk.
        """
        composite_patterns = [
            (
                r"(username|user|login)\s*[:=]\s*(\w+)",
                r"(password|pass|pwd)\s*[:=]\s*(\w+)",
            ),
            (
                r"email\s*[:=]\s*([\w\.\-]+@[\w\.\-]+)",
                r"(password|pass)\s*[:=]\s*(\w+)",
            ),
            (
                r"user=(\w+)",
                r"password=(\w+)",
            ),
        ]

        composites = []
        for user_pat, pass_pat in composite_patterns:
            u = re.search(user_pat, text, re.IGNORECASE)
            p = re.search(pass_pat, text, re.IGNORECASE)
            if u and p:
                composites.append({
                    "type":          "CREDENTIAL_LEAK",
                    "username_part": u.group(),
                    "password_part": p.group(),
                    "risk":          "CRITICAL",
                    "full_match":    f"{u.group()} ... {p.group()}",
                })

        return composites


# ── Standalone test ───────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("🧪 TESTING CUSTOM PRESIDIO ANALYZER")
    print("=" * 60)

    analyzer = CustomPresidioAnalyzer()

    test_inputs = [
        "My email is abdullah@gmail.com",
        "Call me at +92-300-1234567",
        "Student ID: 22-BSCS-456",
        "API key: sk-1234567890abcdefghijklmnopqrstuvwxyz1234",
        "Username: admin Password: secret123",
        "My private password is test123",
        "Employee EMP-00234 needs server access",
    ]

    for i, text in enumerate(test_inputs, 1):
        print(f"\n--- Test {i} ---")
        print("Input:", text)
        pii = analyzer.analyze_text(text)
        if pii:
            print(f"✅ Found {len(pii)} PII entities:")
            for e in pii:
                print(f"   - {e['entity_type']}: '{e['text']}' (conf={e['score']:.2f})")
        else:
            print("❌ No PII detected")

        comps = analyzer.detect_composite_entities(text)
        if comps:
            for c in comps:
                print(f"⚠️  COMPOSITE: {c['full_match']}")

    print("\n" + "=" * 60)
    print("✅ Test Complete")
    print("=" * 60)
