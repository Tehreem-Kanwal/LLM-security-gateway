from enum import Enum
from typing import List, Tuple


class PolicyAction(Enum):
    ALLOW = "allow"
    BLOCK = "block"
    MASK  = "mask"
    FLAG  = "flag"


class PolicyEngine:
    """
    Configurable policy decision engine.

    Rules (in priority order):
    1. Composite credential leak  → BLOCK  (highest risk)
    2. Injection score >= 80      → BLOCK
    3. Injection score >= 50      → FLAG
    4. PII detected               → MASK
    5. Clean input                → ALLOW
    """

    def __init__(
        self,
        injection_block_threshold: int   = 80,
        injection_flag_threshold:  int   = 50,
        pii_confidence_threshold:  float = 0.60,
    ):
        self.inj_block = injection_block_threshold
        self.inj_flag  = injection_flag_threshold
        self.pii_thresh = pii_confidence_threshold

        print("✅ Policy Engine initialized")
        print(f"   - Injection BLOCK threshold : {self.inj_block}")
        print(f"   - Injection FLAG  threshold : {self.inj_flag}")
        print(f"   - PII confidence threshold  : {self.pii_thresh}")

    def decide(
        self,
        injection_score: int,
        pii_results:     List,
        composites:      List,
    ) -> Tuple[PolicyAction, str]:
        """Return (action, reason) based on security analysis."""

        # Rule 1 — Composite credential leak
        if composites:
            return (
                PolicyAction.BLOCK,
                f"Credential leak detected ({len(composites)} credential pair(s))",
            )

        # Rule 2 — Critical injection
        if injection_score >= self.inj_block:
            return (
                PolicyAction.BLOCK,
                f"Critical injection attempt (score: {injection_score}/100)",
            )

        # Rule 3 — Suspicious / moderate injection
        if injection_score >= self.inj_flag:
            return (
                PolicyAction.FLAG,
                f"Suspicious input flagged (score: {injection_score}/100)",
            )

        # Rule 4 — PII present
        if pii_results:
            if isinstance(pii_results[0], dict):
                entity_types = list({r.get("entity_type", "UNKNOWN") for r in pii_results})
            else:
                entity_types = list({r.entity_type for r in pii_results})
            return (
                PolicyAction.MASK,
                f"PII detected: {', '.join(entity_types)} ({len(pii_results)} entity/ies)",
            )

        # Rule 5 — Safe
        return PolicyAction.ALLOW, "No threats detected — input is safe"

    def mask_text(self, text: str, pii_results: List) -> str:
        """Replace PII spans with [TYPE_REDACTED] labels."""
        if not pii_results:
            return text

        masked = text
        if isinstance(pii_results[0], dict):
            sorted_results = sorted(pii_results, key=lambda x: x.get("start", 0), reverse=True)
            for r in sorted_results:
                s, e = r.get("start", 0), r.get("end", 0)
                etype = r.get("entity_type", "PII")
                if 0 <= s < e <= len(masked):
                    masked = masked[:s] + f"[{etype}_REDACTED]" + masked[e:]
        else:
            sorted_results = sorted(pii_results, key=lambda x: x.start, reverse=True)
            for r in sorted_results:
                etype = getattr(r, "entity_type", "PII")
                masked = masked[:r.start] + f"[{etype}_REDACTED]" + masked[r.end:]

        return masked
