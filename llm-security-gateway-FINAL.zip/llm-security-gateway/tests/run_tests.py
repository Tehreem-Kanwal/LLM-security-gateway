"""
Automated test runner — verifies gateway behavior against expected outcomes.
Run from project root:
    python tests/run_tests.py
"""
import sys
import json
from pathlib import Path

project_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(project_root / "src"))

from main import SecurityGateway


def run_tests():
    cases_file = project_root / "tests" / "test_cases.json"
    with open(cases_file) as f:
        data = json.load(f)

    gateway = SecurityGateway()
    cases   = data["test_cases"]
    passed  = 0
    failed  = 0
    results = []

    print("\n" + "=" * 70)
    print("  RUNNING AUTOMATED TESTS")
    print("=" * 70)

    for tc in cases:
        result = gateway.process(tc["input"])
        action = result["action"]

        ok = True
        fail_reasons = []

        if "expected_action" in tc and action != tc["expected_action"]:
            ok = False
            fail_reasons.append(f"expected action={tc['expected_action']}, got={action}")

        if "expected_min_injection_score" in tc:
            if result["injection_score"] < tc["expected_min_injection_score"]:
                ok = False
                fail_reasons.append(
                    f"injection score {result['injection_score']} < {tc['expected_min_injection_score']}"
                )

        if "expected_composite" in tc and tc["expected_composite"]:
            if not result["composites"]:
                ok = False
                fail_reasons.append("expected composite credential detection but none found")

        if ok:
            passed += 1
            status = "✅ PASS"
        else:
            failed += 1
            status = "❌ FAIL"

        print(f"\n[{tc['id']:02d}] {status} — {tc['category']}")
        print(f"     Input:  {tc['input'][:60]}")
        print(f"     Action: {action.upper()}  |  Score: {result['injection_score']}/100  |  PII: {result['pii_count']}")
        if fail_reasons:
            for r in fail_reasons:
                print(f"     ⚠️  {r}")

        results.append({**tc, "actual_action": action,
                        "injection_score": result["injection_score"],
                        "pii_count": result["pii_count"], "passed": ok})

    print("\n" + "=" * 70)
    print(f"  RESULTS: {passed}/{len(cases)} PASSED  |  {failed} FAILED")
    print("=" * 70)
    return results


if __name__ == "__main__":
    run_tests()
